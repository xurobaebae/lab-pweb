// src/pages/DataMahasiswaPage.jsx

import Layout from "./Layout";
import Table from "../components/Table";

export default function DataMahasiswaPage() {
  return (
    <Layout>
      <Table />
    </Layout>
  );
}
